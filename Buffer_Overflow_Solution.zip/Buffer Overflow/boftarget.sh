#!/bin/bash

echo "Compiling the buffer overflow target question.cpp"
g++ -fstack-protector-all question.cpp -o question
echo "Running the executable ./question"
